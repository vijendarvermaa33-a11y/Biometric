# Biometric Android App — stability and splash fix

- App name: Biometric
- First page on launch: https://vijendarverma.in/Biometric/employee/login.php
- Splash artwork and launcher icon are cropped from the user's supplied reference image.
- Splash artwork uses FIT_CENTER and hides system bars during the splash so the full design is visible without clipping or duplicated status/navigation controls.
- Correct AppCompat theme is configured for AppCompatActivity.
- WebView renderer termination is handled by recreating the WebView instead of closing the app.
- All pages on vijendarverma.in remain inside the app; external web domains open outside.
- HTML5 Camera permission, browser Geolocation permission and file chooser are supported.
- Persistent WebView cookies are flushed after page loads, on pause and before destroy.
- Existing PHP hosting and database are unchanged.

## Build
Upload Android.zip to the repository root and `.github/workflows/build-apk.yml` to the matching workflow path. Run Actions -> Build Biometric APK -> Run workflow. Download the Biometric-APK artifact and extract Biometric.apk.

## Upgrade
This release uses versionCode 2 / versionName 1.0.1. If Android refuses to update due to signature mismatch, uninstall the previous test APK then install the new one. Uninstalling clears local app cookies, so the employee will need to log in once again.

## Important
This package is an Android APK. iOS requires a separate Xcode project. Camera and location access still require user permission. Long-lived PHP login depends on the hosting server retaining PHP session data as well as the cookie.
